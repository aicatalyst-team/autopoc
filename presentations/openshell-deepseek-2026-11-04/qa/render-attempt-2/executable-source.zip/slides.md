---
theme: default
title: AutoPoC executive summary
favicon: /brand/logos/redhat-hat-standard.svg
canvasWidth: 1280
aspectRatio: 16/9
download: false
transition: none
wakeLock: false
fonts:
  provider: none
  sans: Red Hat Text
  mono: Red Hat Mono
---

<ExecutiveSlide kind="purpose" />

<!-- Explain archived evidence; animation timing is illustrative. See narrative.json for claim references. -->

---
layout: default
---

<ExecutiveSlide kind="testing_strategy" />

<!-- Explain archived evidence; animation timing is illustrative. See narrative.json for claim references. -->

---
layout: default
---

<ExecutiveSlide kind="topology" />

<!-- Explain archived evidence; animation timing is illustrative. See narrative.json for claim references. -->

---
layout: default
---

<ExecutiveSlide kind="test_execution" />

<!-- Explain archived evidence; animation timing is illustrative. See narrative.json for claim references. -->

---
layout: default
---

<ExecutiveSlide kind="results" />

<!-- Explain archived evidence; animation timing is illustrative. See narrative.json for claim references. -->

---
layout: default
---

<ExecutiveSlide kind="platform_suitability" />

<!-- Explain archived evidence; animation timing is illustrative. See narrative.json for claim references. -->
